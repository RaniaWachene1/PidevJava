/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agencedelocationdevoiture;

import java.util.List;
import java.util.Vector;

/**
 *
 * @author wiemhjiri
 */
public class ListVoitures {
    private List<Voiture> voitures;

    public ListVoitures(List<Voiture> voitures) { 
//à compléter

    }
public ListVoitures() {
//à compléter
}
public List<Voiture> getVoitures() {
//à compléter
}
public void setVoitures(List<Voiture> voitures) {
//à compléter
}
public void ajoutVoiture(Voiture v) throws VoitureException{
//à compléter
}

public void supprimeVoiture(Voiture v) throws VoitureException{
// à compléter
}

public int size(){
}
public void affiche(){
}

    @Override
    public String toString() {
    }

}
